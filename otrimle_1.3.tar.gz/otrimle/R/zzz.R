.onAttach <- function(lib, pkg) {
  packageStartupMessage("\nOTRIMLE: Robust Model-Based Clustering\nType 'citation(\"otrimle\")' for citing this R package in publications.\n")
  invisible()
}
